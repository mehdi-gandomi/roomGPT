export interface SimilarElement {
    title: string,
    price: string,
    image: string,
}